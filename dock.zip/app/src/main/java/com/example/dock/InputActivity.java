package com.example.dock;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.media.tv.TvContract;
import android.media.tv.TvView;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;

public class InputActivity extends Activity {
    TvView tv;
    String id;
    boolean fellBack = false;

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        id = getIntent().getStringExtra("id");
        String label = getIntent().getStringExtra("label");
        if (id == null) { finish(); return; }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        tv = new TvView(this);
        root.addView(tv, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        tv.setCallback(new TvView.TvInputCallback() {
            @Override public void onConnectionFailed(String inputId) { fallBack(); }
            @Override public void onDisconnected(String inputId) { finish(); }
        });
        Toast.makeText(this, (label == null ? "Input" : label) + "  ·  Back to return", Toast.LENGTH_LONG).show();
    }

    @Override protected void onResume() {
        super.onResume();
        if (tv != null && id != null) {
            try { tv.tune(id, TvContract.buildChannelUriForPassthroughInput(id)); }
            catch (Exception e) { fallBack(); }
        }
    }

    @Override protected void onPause() {
        super.onPause();
        if (tv != null) tv.reset();
    }

    // if the TV won't let us show the input directly, hand it to Amazon's Live TV like before
    void fallBack() {
        if (fellBack) return;
        fellBack = true;
        try { startActivity(new Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(id))); }
        catch (Exception e) { }
        finish();
    }
}
