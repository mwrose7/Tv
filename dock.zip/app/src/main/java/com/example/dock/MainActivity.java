package com.example.dock;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.*;
import android.view.animation.LinearInterpolator;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static final long ROTATE_MS = 3 * 60 * 1000L;
    // Prime Video, Netflix, YouTube, Disney+, Plex, Kodi: first six installed are used on first run.
    static final String[] DEFAULTS = {
        "com.amazon.firebat", "com.amazon.amazonvideo.livingroom", "com.netflix.ninja",
        "com.amazon.firetv.youtube", "com.disney.disneyplus", "com.plexapp.android", "org.xbmc.kodi"
    };

    FrameLayout root, overlay;
    ImageView bgA, bgB;
    LinearLayout dock;
    View info;
    TextView greeting;
    SharedPreferences prefs;
    PackageManager pm;
    final Handler h = new Handler(Looper.getMainLooper());
    final Runnable rotate = new Runnable() { public void run() { nextWallpaper(false); } };
    int wp = 0;
    boolean front = true, started = false;
    float d;

    int dp(int v) { return Math.round(v * d); }

    // ---------- small drawn icons for the built-in tiles ----------
    static class Glyph extends View {
        final int type;
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Glyph(Context c, int type) { super(c); this.type = type; }

        @Override protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            p.setColor(0xF5FFFFFF);
            if (type == 0) {
                p.setStyle(Paint.Style.FILL);
                float s = w * 0.2f, g = w * 0.08f;
                float x0 = w / 2f - s - g / 2f, y0 = h / 2f - s - g / 2f;
                for (int i = 0; i < 2; i++) {
                    for (int j = 0; j < 2; j++) {
                        float x = x0 + i * (s + g), y = y0 + j * (s + g);
                        c.drawRoundRect(new RectF(x, y, x + s, y + s), s * 0.28f, s * 0.28f, p);
                    }
                }
            } else if (type == 1) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(w * 0.055f);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeJoin(Paint.Join.ROUND);
                c.drawRoundRect(new RectF(w * 0.34f, h * 0.30f, w * 0.80f, h * 0.66f), w * 0.05f, w * 0.05f, p);
                c.drawLine(w * 0.57f, h * 0.66f, w * 0.57f, h * 0.76f, p);
                c.drawLine(w * 0.47f, h * 0.76f, w * 0.67f, h * 0.76f, p);
                c.drawLine(w * 0.14f, h * 0.48f, w * 0.46f, h * 0.48f, p);
                c.drawLine(w * 0.37f, h * 0.40f, w * 0.46f, h * 0.48f, p);
                c.drawLine(w * 0.37f, h * 0.56f, w * 0.46f, h * 0.48f, p);
            } else {
                float cx = w / 2f, cy = h / 2f;
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(w * 0.075f);
                c.drawCircle(cx, cy, w * 0.17f, p);
                p.setStyle(Paint.Style.FILL);
                for (int i = 0; i < 8; i++) {
                    c.save();
                    c.rotate(i * 45f, cx, cy);
                    c.drawRoundRect(new RectF(cx - w * 0.05f, cy - w * 0.33f, cx + w * 0.05f, cy - w * 0.22f), w * 0.02f, w * 0.02f, p);
                    c.restore();
                }
            }
        }
    }

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        d = getResources().getDisplayMetrics().density;
        pm = getPackageManager();
        prefs = getSharedPreferences("dock", MODE_PRIVATE);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setClipChildren(false);
        bgA = newBg(); bgB = newBg();
        root.addView(bgA, new FrameLayout.LayoutParams(-1, -1));
        root.addView(bgB, new FrameLayout.LayoutParams(-1, -1));

        // soft shading so the clock and dock always read clearly
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{0x66000000, 0x00000000, 0x00000000, 0xB8000000}));
        root.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        // top-left: greeting, big clock, date (kept inside the TV's safe area)
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        greeting = new TextView(this);
        greeting.setTextColor(0xE6FFFFFF);
        greeting.setTextSize(20);
        greeting.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        greeting.setShadowLayer(10, 0, 2, 0x99000000);
        box.addView(greeting);
        TextClock clock = new TextClock(this);
        clock.setFormat12Hour("h:mm a");
        clock.setFormat24Hour("HH:mm");
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(58);
        clock.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        clock.setShadowLayer(14, 0, 3, 0x99000000);
        clock.setIncludeFontPadding(false);
        box.addView(clock);
        TextClock date = new TextClock(this);
        date.setFormat12Hour("EEEE, MMMM d");
        date.setFormat24Hour("EEEE, MMMM d");
        date.setTextColor(0xD9FFFFFF);
        date.setTextSize(20);
        date.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        date.setShadowLayer(10, 0, 2, 0x99000000);
        box.addView(date);
        info = box;
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        ip.setMargins(dp(80), dp(48), 0, 0);
        root.addView(box, ip);

        // dock: frosted-glass look
        dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER);
        dock.setClipChildren(false);
        dock.setClipToPadding(false);
        dock.setPadding(dp(20), dp(18), dp(20), dp(14));
        GradientDrawable dbg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{0x70FFFFFF, 0x30FFFFFF});
        dbg.setCornerRadius(dp(40));
        dbg.setStroke(Math.max(2, dp(1)), 0x55FFFFFF);
        dock.setBackground(dbg);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        dlp.setMargins(0, 0, 0, dp(52));
        root.addView(dock, dlp);

        setContentView(root);
        buildDock(0);
    }

    @Override protected void onResume() {
        super.onResume();
        updateGreeting();
        if (!started) { started = true; nextWallpaper(true); }
        else { h.removeCallbacks(rotate); h.postDelayed(rotate, ROTATE_MS); }
        buildDock(0);
    }

    @Override protected void onPause() { super.onPause(); h.removeCallbacks(rotate); }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); closeOverlay(); }

    @Override public void onBackPressed() { if (overlay != null) closeOverlay(); }

    void updateGreeting() {
        int hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String g = hr < 5 ? "Good night" : hr < 12 ? "Good morning" : hr < 18 ? "Good afternoon" : "Good evening";
        greeting.setText(g);
    }

    ImageView newBg() {
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setAlpha(0f);
        return iv;
    }

    // ---------- wallpapers ----------
    void nextWallpaper(final boolean first) {
        final int idx = wp++;
        h.removeCallbacks(rotate);
        h.postDelayed(rotate, ROTATE_MS);
        // draw on a background thread so the dock never stutters
        new Thread(new Runnable() {
            public void run() {
                final Bitmap b = loadWallpaper(idx);
                h.post(new Runnable() { public void run() { applyWallpaper(b, first); } });
            }
        }).start();
    }

    void applyWallpaper(Bitmap b, boolean first) {
        ImageView in = front ? bgB : bgA, out = front ? bgA : bgB;
        Object old = in.getTag();
        if (old instanceof AnimatorSet) ((AnimatorSet) old).cancel();
        in.setScaleX(1f);
        in.setScaleY(1f);
        in.setImageBitmap(b);
        if (first) { in.setAlpha(1f); out.setAlpha(0f); }
        else { in.animate().alpha(1f).setDuration(1800); out.animate().alpha(0f).setDuration(1800); }
        // slow "Ken Burns" drift so the scene never feels static
        ObjectAnimator sx = ObjectAnimator.ofFloat(in, View.SCALE_X, 1f, 1.09f);
        ObjectAnimator sy = ObjectAnimator.ofFloat(in, View.SCALE_Y, 1f, 1.09f);
        AnimatorSet set = new AnimatorSet();
        set.playTogether(sx, sy);
        set.setDuration(ROTATE_MS + 4000);
        set.setInterpolator(new LinearInterpolator());
        in.setTag(set);
        set.start();
        front = !front;
    }

    // Uses your own photos if you add res/drawable-nodpi/wp1.jpg, wp2.jpg, ...; otherwise draws scenes.
    Bitmap loadWallpaper(int i) {
        int n = 0;
        while (getResources().getIdentifier("wp" + (n + 1), "drawable", getPackageName()) != 0) n++;
        if (n > 0) {
            int id = getResources().getIdentifier("wp" + (i % n + 1), "drawable", getPackageName());
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inPreferredConfig = Bitmap.Config.RGB_565;
            Bitmap b = BitmapFactory.decodeResource(getResources(), id, o);
            if (b != null) return b;
        }
        return scene(i);
    }

    int mix(int a, int b, float t) {
        int r = Math.round(Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = Math.round(Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = Math.round(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }

    float ridge(float base, float amp, float f1, float f2, float p1, float p2, float x, float w) {
        double t = x / w * 6.2832;
        return (float) (base - amp * (0.6 * Math.sin(t * f1 + p1) + 0.4 * Math.sin(t * f2 + p2)));
    }

    void pine(Canvas c, Paint paint, Path tri, float x, float y, float ph) {
        float pw = ph * 0.36f;
        for (int k = 0; k < 3; k++) {
            float apexY = y - ph + k * ph * 0.27f;
            float baseY = apexY + ph * 0.46f;
            float half = pw * (0.45f + 0.28f * k);
            tri.rewind();
            tri.moveTo(x, apexY);
            tri.lineTo(x - half, baseY);
            tri.lineTo(x + half, baseY);
            tri.close();
            c.drawPath(tri, paint);
        }
    }

    Bitmap scene(int i) {
        int w = 1600, h = 900;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        // {horizon, sky top, dark foreground}
        int[][] pal = {
            {0xFFFFC38A, 0xFF5A3A7A, 0xFF2D1B3D},
            {0xFFBFE6FF, 0xFF3E7FB5, 0xFF16384F},
            {0xFFF7E7A8, 0xFF6FAF86, 0xFF1F4A33},
            {0xFF6A5BA0, 0xFF0F1A48, 0xFF0A0F26},
            {0xFFFFD9A0, 0xFFD9764F, 0xFF4A2A3A},
            {0xFFD6EEF2, 0xFF6EA3BD, 0xFF24475A},
            {0xFF9FE3D1, 0xFF0B3040, 0xFF08202B},
            {0xFFFFE9B0, 0xFFE8825A, 0xFF3A1F2E}
        };
        int pi = i % pal.length;
        int[] p = pal[pi];
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setDither(true);

        // sky
        int midSky = mix(p[1], p[0], 0.55f);
        paint.setShader(new LinearGradient(0, 0, 0, h * 0.72f, new int[]{p[1], midSky, p[0]},
            new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, paint);
        paint.setShader(null);

        Random r = new Random(i * 7919L + 13);

        // stars on the dark skies
        float lum = (Color.red(p[1]) * 0.299f + Color.green(p[1]) * 0.587f + Color.blue(p[1]) * 0.114f) / 255f;
        if (lum < 0.3f) {
            for (int k = 0; k < 220; k++) {
                float stx = r.nextFloat() * w, sty = r.nextFloat() * h * 0.5f;
                float a = 0.25f + 0.75f * r.nextFloat();
                paint.setColor(Color.argb((int) (a * 255), 255, 255, 255));
                c.drawCircle(stx, sty, 0.8f + r.nextFloat() * 1.6f, paint);
            }
        }

        // sun / moon with a wide glow
        float sx = w * (0.2f + 0.6f * r.nextFloat()), sy = h * (0.26f + 0.14f * r.nextFloat()), sr = h * 0.07f;
        paint.setShader(new RadialGradient(sx, sy, sr * 6f, new int[]{0x88FFFFFF, 0x22FFFFFF, 0x00FFFFFF},
            new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(sx, sy, sr * 6f, paint);
        paint.setShader(null);
        paint.setColor(0xF2FFFFF0);
        c.drawCircle(sx, sy, sr, paint);

        // mountain ridges with mist between them
        final int LAYERS = 5;
        float[] base = new float[LAYERS], amp = new float[LAYERS], f1 = new float[LAYERS], f2 = new float[LAYERS];
        float[] p1 = new float[LAYERS], p2 = new float[LAYERS];
        for (int L = 0; L < LAYERS; L++) {
            base[L] = h * (0.46f + 0.105f * L);
            amp[L] = h * (0.11f - 0.012f * L);
            f1[L] = 2 + r.nextFloat() * 2;
            f2[L] = 5 + r.nextFloat() * 4;
            p1[L] = r.nextFloat() * 6.28f;
            p2[L] = r.nextFloat() * 6.28f;
        }
        int hz = p[0] & 0x00FFFFFF;
        boolean pines = pi == 0 || pi == 2 || pi == 3 || pi == 6;
        Path path = new Path();
        Path tri = new Path();
        for (int L = 0; L < LAYERS; L++) {
            path.rewind();
            path.moveTo(0, h);
            for (int x = 0; x <= w; x += 8) {
                path.lineTo(x, ridge(base[L], amp[L], f1[L], f2[L], p1[L], p2[L], x, w));
            }
            path.lineTo(w, h);
            path.close();
            float t = L / (float) (LAYERS - 1);
            int col = mix(p[0], p[2], 0.28f + 0.72f * t);
            paint.setShader(new LinearGradient(0, base[L] - amp[L], 0, h, col, mix(col, p[2], 0.5f), Shader.TileMode.CLAMP));
            c.drawPath(path, paint);
            paint.setShader(null);

            if (pines && L >= LAYERS - 2) {
                paint.setColor(mix(col, p[2], 0.4f));
                float hMin = (L == LAYERS - 1) ? h * 0.04f : h * 0.025f;
                float hVar = (L == LAYERS - 1) ? h * 0.05f : h * 0.03f;
                for (float x = 6; x < w; x += 16 + r.nextFloat() * 22) {
                    float ry = ridge(base[L], amp[L], f1[L], f2[L], p1[L], p2[L], x, w);
                    pine(c, paint, tri, x, ry + 3, hMin + hVar * r.nextFloat());
                }
            }

            if (L < LAYERS - 1) {
                float my = base[L + 1] - amp[L + 1];
                paint.setShader(new LinearGradient(0, my - h * 0.10f, 0, my + h * 0.08f,
                    new int[]{hz, 0x55000000 | hz, hz}, new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
                c.drawRect(0, my - h * 0.10f, w, my + h * 0.08f, paint);
                paint.setShader(null);
            }
        }
        return bmp;
    }

    // ---------- dock ----------
    Intent launchIntent(String pkg) {
        Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
        return i != null ? i : pm.getLaunchIntentForPackage(pkg);
    }

    void launch(String pkg) {
        try { Intent i = launchIntent(pkg); if (i != null) startActivity(i); }
        catch (Exception e) { toast("Can't open that app"); }
    }

    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    List<String> favorites() {
        String s = prefs.getString("favs", null);
        List<String> out = new ArrayList<>();
        if (s == null) {
            for (String p : DEFAULTS) if (out.size() < 6 && launchIntent(p) != null) out.add(p);
            saveFavs(out);
        } else {
            for (String p : s.split(",")) if (!p.isEmpty()) out.add(p);
        }
        return out;
    }

    void saveFavs(List<String> l) { prefs.edit().putString("favs", TextUtils.join(",", l)).apply(); }

    void addFav(String pkg) {
        List<String> f = favorites();
        if (f.contains(pkg)) { toast("Already in dock"); return; }
        f.add(pkg);
        saveFavs(f);
        toast("Added to dock");
    }

    void roundClip(View v, final int radiusDp) {
        v.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline o) {
                o.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(radiusDp));
            }
        });
        v.setClipToOutline(true);
    }

    View iconView(Drawable dr) {
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(dr);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setBackgroundColor(0x33FFFFFF);
        roundClip(iv, 22);
        return iv;
    }

    View glyph(int type, int c1, int c2) {
        Glyph g = new Glyph(this, type);
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        gd.setCornerRadius(dp(22));
        g.setBackground(gd);
        return g;
    }

    View tile(String text, int sp, int c1, int c2) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sp);
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        tv.setGravity(Gravity.CENTER);
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        gd.setCornerRadius(dp(22));
        tv.setBackground(gd);
        return tv;
    }

    View item(View icon, int iconDp, String label, boolean alwaysLabel, View.OnClickListener click, View.OnLongClickListener lc) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setClipChildren(false);
        box.setClipToPadding(false);
        box.setPadding(dp(8), dp(8), dp(8), dp(4));
        box.setFocusable(true);
        box.setClickable(true);

        FrameLayout holder = new FrameLayout(this);
        holder.setClipChildren(false);
        holder.addView(icon, new FrameLayout.LayoutParams(-1, -1));
        final View ring = new View(this);
        GradientDrawable rg = new GradientDrawable();
        rg.setColor(Color.TRANSPARENT);
        rg.setCornerRadius(dp(24));
        rg.setStroke(Math.max(3, dp(2)), 0xF2FFFFFF);
        ring.setBackground(rg);
        ring.setAlpha(0f);
        holder.addView(ring, new FrameLayout.LayoutParams(-1, -1));
        box.addView(holder, new LinearLayout.LayoutParams(dp(iconDp), dp(iconDp)));

        final TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(14);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER);
        t.setShadowLayer(8, 0, 1, 0xCC000000);
        t.setAlpha(alwaysLabel ? 0.85f : 0f);
        final boolean always = alwaysLabel;
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(dp(iconDp + 20), dp(26));
        tp.topMargin = dp(6);
        box.addView(t, tp);

        box.setOnClickListener(click);
        if (lc != null) box.setOnLongClickListener(lc);
        box.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View view, boolean focused) {
                float sc = focused ? 1.16f : 1f;
                view.animate().scaleX(sc).scaleY(sc).translationY(focused ? -dp(8) : 0).setDuration(140);
                t.animate().alpha(focused ? 1f : (always ? 0.85f : 0f)).setDuration(140);
                ring.animate().alpha(focused ? 1f : 0f).setDuration(140);
            }
        });
        return box;
    }

    LinearLayout.LayoutParams itemLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(dp(4), 0, dp(4), 0);
        return lp;
    }

    void buildDock(int focusIdx) {
        dock.removeAllViews();
        final List<String> favs = favorites();
        final List<String> pk = new ArrayList<>();
        final List<String> lb = new ArrayList<>();
        final List<Drawable> ic = new ArrayList<>();
        for (String p : favs) {
            if (launchIntent(p) == null) continue;
            try {
                Drawable dr = pm.getApplicationIcon(p);
                String l = pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString();
                pk.add(p); ic.add(dr); lb.add(l);
            } catch (Exception e) { }
        }
        // shrink icons if there are many, so the dock always fits the screen
        int count = pk.size() + 3;
        float screenDp = getResources().getDisplayMetrics().widthPixels / d;
        int avail = (int) (screenDp - 160 - 40 - 20);
        int iconDp = Math.max(56, Math.min(92, avail / count - 24));

        for (int n = 0; n < pk.size(); n++) {
            final String pkg = pk.get(n);
            dock.addView(item(iconView(ic.get(n)), iconDp, lb.get(n), false,
                v -> launch(pkg),
                v -> { favs.remove(pkg); saveFavs(favs); toast("Removed from dock"); buildDock(0); return true; }), itemLp());
        }
        if (!pk.isEmpty()) {
            View div = new View(this);
            div.setBackgroundColor(0x55FFFFFF);
            LinearLayout.LayoutParams dv = new LinearLayout.LayoutParams(Math.max(2, dp(1)), dp(52));
            dv.setMargins(dp(8), 0, dp(8), dp(24));
            dock.addView(div, dv);
        }
        dock.addView(item(glyph(0, 0xFF6C7BFF, 0xFF9B5CFF), iconDp, "All apps", false, v -> showAll(), null), itemLp());
        dock.addView(item(glyph(1, 0xFF22C3B0, 0xFF1C7FC4), iconDp, "Inputs", false, v -> showInputs(), null), itemLp());
        dock.addView(item(glyph(2, 0xFF7B8494, 0xFF3F4756), iconDp, "Settings", false, v -> openSettings(), null), itemLp());
        if (overlay == null) {
            View first = dock.getChildAt(0);
            if (first != null) first.requestFocus();
        }
    }

    void openSettings() {
        try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
        catch (Exception e) { launch("com.amazon.tv.settings.v2"); }
    }

    void startInput(String id) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(id)));
        } catch (Exception e) { toast("Can't open that input"); }
    }

    // ---------- overlays (inputs, all apps) ----------
    LinearLayout openOverlay(String title, String hint) {
        overlay = new FrameLayout(this);
        overlay.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{0xF2161628, 0xF20A0A14}));
        overlay.setClickable(true);
        ScrollView sv = new ScrollView(this);
        sv.setClipChildren(false);
        sv.setClipToPadding(false);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setClipChildren(false);
        col.setClipToPadding(false);
        col.setPadding(dp(80), dp(56), dp(80), dp(56));
        TextView ttl = new TextView(this);
        ttl.setText(title);
        ttl.setTextColor(Color.WHITE);
        ttl.setTextSize(34);
        ttl.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        col.addView(ttl);
        TextView hn = new TextView(this);
        hn.setText(hint);
        hn.setTextColor(0xAAFFFFFF);
        hn.setTextSize(16);
        hn.setPadding(0, dp(4), 0, dp(28));
        col.addView(hn);
        sv.addView(col);
        overlay.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        dock.setVisibility(View.INVISIBLE);   // keeps remote focus inside the overlay
        return col;
    }

    void showInputs() {
        if (overlay != null) return;
        List<TvInputInfo> ins = new ArrayList<>();
        try {
            TvInputManager tim = (TvInputManager) getSystemService(Context.TV_INPUT_SERVICE);
            if (tim != null) for (TvInputInfo ti : tim.getTvInputList()) if (ti.isPassthroughInput()) ins.add(ti);
        } catch (Exception e) { }
        if (ins.isEmpty()) {
            // fall back to Amazon's own Live TV screen, which has the input bar
            toast("Opening Live TV");
            launch("com.amazon.tv.livetv");
            return;
        }
        LinearLayout col = openOverlay("Inputs", "Choose an input  ·  Back to close");
        LinearLayout row = null;
        View first = null;
        int n = 0;
        for (final TvInputInfo ti : ins) {
            if (n % 5 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setClipChildren(false);
                col.addView(row);
            }
            CharSequence l = null;
            try { l = ti.loadLabel(this); } catch (Exception e) { }
            String label = (l == null || l.length() == 0) ? ti.getId() : l.toString();
            View it = item(tile(label, 16, 0xFF22C3B0, 0xFF1C7FC4), 96, label, true,
                v -> { closeOverlay(); startInput(ti.getId()); }, null);
            row.addView(it, new LinearLayout.LayoutParams(dp(150), -2));
            if (first == null) first = it;
            n++;
        }
        if (first != null) first.requestFocus();
    }

    Map<String, ResolveInfo> launchables() {
        Map<String, ResolveInfo> m = new LinkedHashMap<>();
        for (String cat : new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER}) {
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String p = ri.activityInfo.packageName;
                if (!p.equals(getPackageName()) && !m.containsKey(p)) m.put(p, ri);
            }
        }
        return m;
    }

    void showAll() {
        if (overlay != null) return;
        LinearLayout col = openOverlay("All apps",
            "Select to open  ·  Hold select to add to your dock  ·  Back to close");
        List<ResolveInfo> list = new ArrayList<>(launchables().values());
        Collections.sort(list, new Comparator<ResolveInfo>() {
            public int compare(ResolveInfo a, ResolveInfo b) {
                return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());
            }
        });
        LinearLayout row = null;
        View first = null;
        int n = 0;
        for (ResolveInfo ri : list) {
            if (n % 6 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setClipChildren(false);
                col.addView(row);
            }
            final String pkg = ri.activityInfo.packageName;
            View it = item(iconView(ri.loadIcon(pm)), 88, ri.loadLabel(pm).toString(), true,
                v -> { closeOverlay(); launch(pkg); },
                v -> { addFav(pkg); return true; });
            row.addView(it, new LinearLayout.LayoutParams(dp(128), -2));
            if (first == null) first = it;
            n++;
        }
        if (first != null) first.requestFocus();
    }

    void closeOverlay() {
        if (overlay != null) {
            root.removeView(overlay);
            overlay = null;
            dock.setVisibility(View.VISIBLE);
            buildDock(0);
        }
    }
}
