package com.example.dock;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static final long ROTATE_MS = 3 * 60 * 1000L;
    // Prime Video (firebat / livingroom), Netflix, YouTube, Disney+, Plex, Kodi: first six installed are used on first run.
    static final String[] DEFAULTS = {
        "com.amazon.firebat", "com.amazon.amazonvideo.livingroom", "com.netflix.ninja",
        "com.amazon.firetv.youtube", "com.disney.disneyplus", "com.plexapp.android", "org.xbmc.kodi"
    };

    FrameLayout root, overlay;
    ImageView bgA, bgB;
    LinearLayout dock;
    SharedPreferences prefs;
    PackageManager pm;
    final Handler h = new Handler(Looper.getMainLooper());
    final Runnable rotate = new Runnable() { public void run() { nextWallpaper(false); } };
    int wp = 0;
    boolean front = true, started = false;
    float d;

    int dp(int v) { return Math.round(v * d); }

    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        d = getResources().getDisplayMetrics().density;
        pm = getPackageManager();
        prefs = getSharedPreferences("dock", MODE_PRIVATE);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setClipChildren(false);
        bgA = newBg(); bgB = newBg();
        root.addView(bgA, new FrameLayout.LayoutParams(-1, -1));
        root.addView(bgB, new FrameLayout.LayoutParams(-1, -1));

        TextClock clock = new TextClock(this);
        clock.setFormat12Hour("h:mm a");
        clock.setFormat24Hour("HH:mm");
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(26);
        clock.setShadowLayer(8, 0, 2, 0x99000000);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.END);
        cp.setMargins(0, dp(24), dp(40), 0);
        root.addView(clock, cp);

        dock = new LinearLayout(this);
        dock.setOrientation(LinearLayout.HORIZONTAL);
        dock.setGravity(Gravity.CENTER);
        dock.setClipChildren(false);
        dock.setPadding(dp(18), dp(14), dp(18), dp(10));
        GradientDrawable dbg = new GradientDrawable();
        dbg.setColor(0x66101018);
        dbg.setCornerRadius(dp(36));
        dock.setBackground(dbg);
        FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        dlp.setMargins(0, 0, 0, dp(32));
        root.addView(dock, dlp);

        setContentView(root);
        buildDock(0);
    }

    @Override protected void onResume() {
        super.onResume();
        if (!started) { started = true; nextWallpaper(true); }
        else { h.removeCallbacks(rotate); h.postDelayed(rotate, ROTATE_MS); }
        buildDock(0);
    }

    @Override protected void onPause() { super.onPause(); h.removeCallbacks(rotate); }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); closeOverlay(); }

    @Override public void onBackPressed() { if (overlay != null) closeOverlay(); }

    ImageView newBg() {
        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setAlpha(0f);
        return iv;
    }

    // ---------- wallpapers ----------
    void nextWallpaper(boolean first) {
        Bitmap b = loadWallpaper(wp++);
        ImageView in = front ? bgB : bgA, out = front ? bgA : bgB;
        in.setImageBitmap(b);
        if (first) { in.setAlpha(1f); out.setAlpha(0f); }
        else { in.animate().alpha(1f).setDuration(1500); out.animate().alpha(0f).setDuration(1500); }
        front = !front;
        h.removeCallbacks(rotate);
        h.postDelayed(rotate, ROTATE_MS);
    }

    // Uses your own photos if you add res/drawable-nodpi/wp1.jpg, wp2.jpg, ...; otherwise draws scenes.
    Bitmap loadWallpaper(int i) {
        int n = 0;
        while (getResources().getIdentifier("wp" + (n + 1), "drawable", getPackageName()) != 0) n++;
        if (n > 0) {
            int id = getResources().getIdentifier("wp" + (i % n + 1), "drawable", getPackageName());
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inPreferredConfig = Bitmap.Config.RGB_565;
            Bitmap b = BitmapFactory.decodeResource(getResources(), id, o);
            if (b != null) return b;
        }
        return scene(i);
    }

    int mix(int a, int b, float t) {
        int r = Math.round(Color.red(a) + (Color.red(b) - Color.red(a)) * t);
        int g = Math.round(Color.green(a) + (Color.green(b) - Color.green(a)) * t);
        int bl = Math.round(Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t);
        return Color.rgb(r, g, bl);
    }

    Bitmap scene(int i) {
        int w = 1280, h = 720;
        Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        // {horizon, sky top, dark foreground}
        int[][] pal = {
            {0xFFFFC38A, 0xFF7A4A8A, 0xFF2D1B3D}, {0xFFA8DCFF, 0xFF4F8FC0, 0xFF16384F},
            {0xFFF7E7A8, 0xFF8DBF8A, 0xFF1F4A33}, {0xFF5A4B8A, 0xFF1B2A5E, 0xFF0A0F26},
            {0xFFFFD9A0, 0xFFE98F6A, 0xFF4A2A3A}, {0xFFCFE8F0, 0xFF86B5C9, 0xFF24475A}
        };
        int[] p = pal[i % pal.length];
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setShader(new LinearGradient(0, 0, 0, h * 0.75f, p[1], p[0], Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, paint);
        Random r = new Random(i * 7919L + 13);
        float sx = w * (0.2f + 0.6f * r.nextFloat()), sy = h * (0.30f + 0.12f * r.nextFloat()), sr = h * 0.08f;
        paint.setShader(new RadialGradient(sx, sy, sr * 3.5f, new int[]{0xAAFFFFFF, 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
        c.drawCircle(sx, sy, sr * 3.5f, paint);
        paint.setShader(null);
        paint.setColor(0xEEFFFFF0);
        c.drawCircle(sx, sy, sr, paint);
        for (int L = 0; L < 4; L++) {
            float base = h * (0.50f + 0.13f * L), amp = h * (0.12f - 0.015f * L);
            float f1 = 2 + r.nextFloat() * 2, f2 = 5 + r.nextFloat() * 4;
            float p1 = r.nextFloat() * 6.28f, p2 = r.nextFloat() * 6.28f;
            Path path = new Path();
            path.moveTo(0, h);
            for (int x = 0; x <= w; x += 8) {
                double t = x / (double) w * 6.2832;
                float y = (float) (base - amp * (0.6 * Math.sin(t * f1 + p1) + 0.4 * Math.sin(t * f2 + p2)));
                path.lineTo(x, y);
            }
            path.lineTo(w, h);
            path.close();
            paint.setColor(mix(p[0], p[2], 0.35f + 0.65f * L / 3f));
            c.drawPath(path, paint);
        }
        return bmp;
    }

    // ---------- dock ----------
    Intent launchIntent(String pkg) {
        Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
        return i != null ? i : pm.getLaunchIntentForPackage(pkg);
    }

    void launch(String pkg) {
        try { Intent i = launchIntent(pkg); if (i != null) startActivity(i); }
        catch (Exception e) { toast("Can't open that app"); }
    }

    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    List<String> favorites() {
        String s = prefs.getString("favs", null);
        List<String> out = new ArrayList<>();
        if (s == null) {
            for (String p : DEFAULTS) if (out.size() < 6 && launchIntent(p) != null) out.add(p);
            saveFavs(out);
        } else {
            for (String p : s.split(",")) if (!p.isEmpty()) out.add(p);
        }
        return out;
    }

    void saveFavs(List<String> l) { prefs.edit().putString("favs", TextUtils.join(",", l)).apply(); }

    void addFav(String pkg) {
        List<String> f = favorites();
        if (f.contains(pkg)) { toast("Already in dock"); return; }
        f.add(pkg);
        saveFavs(f);
        toast("Added to dock");
        buildDock(0);
    }

    void roundClip(View v, final int radiusDp) {
        v.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View view, Outline o) {
                o.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(radiusDp));
            }
        });
        v.setClipToOutline(true);
    }

    View iconView(Drawable dr) {
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(dr);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setBackgroundColor(0x33FFFFFF);
        roundClip(iv, 18);
        return iv;
    }

    View item(View icon, String label, View.OnClickListener click, View.OnLongClickListener lc) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setClipChildren(false);
        box.setPadding(dp(10), dp(8), dp(10), dp(4));
        box.setFocusable(true);
        box.setClickable(true);
        box.addView(icon, new LinearLayout.LayoutParams(dp(84), dp(84)));
        final TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER);
        t.setShadowLayer(6, 0, 1, 0xCC000000);
        t.setAlpha(0f);
        box.addView(t, new LinearLayout.LayoutParams(dp(100), -2));
        box.setOnClickListener(click);
        if (lc != null) box.setOnLongClickListener(lc);
        box.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean f) {
                float sc = f ? 1.22f : 1f;
                v.animate().scaleX(sc).scaleY(sc).setDuration(120);
                t.animate().alpha(f ? 1f : 0f).setDuration(120);
            }
        });
        return box;
    }

    void buildDock(int focusIdx) {
        dock.removeAllViews();
        final List<String> favs = favorites();
        for (final String pkg : favs) {
            if (launchIntent(pkg) == null) continue;
            Drawable ic;
            String lab;
            try {
                ic = pm.getApplicationIcon(pkg);
                lab = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
            } catch (Exception e) { continue; }
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.setMargins(dp(6), 0, dp(6), 0);
            dock.addView(item(iconView(ic), lab,
                v -> launch(pkg),
                v -> { favs.remove(pkg); saveFavs(favs); toast("Removed from dock"); buildDock(0); return true; }), lp);
        }
        TextView plus = new TextView(this);
        plus.setText("+");
        plus.setTextSize(36);
        plus.setTextColor(Color.WHITE);
        plus.setGravity(Gravity.CENTER);
        plus.setBackgroundColor(0x33FFFFFF);
        roundClip(plus, 18);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(-2, -2);
        plp.setMargins(dp(6), 0, dp(6), 0);
        dock.addView(item(plus, "All apps", v -> showAll(), null), plp);
        if (overlay == null) {
            View f = dock.getChildAt(Math.min(focusIdx, dock.getChildCount() - 1));
            if (f != null) f.requestFocus();
        }
    }

    // ---------- all apps ----------
    Map<String, ResolveInfo> launchables() {
        Map<String, ResolveInfo> m = new LinkedHashMap<>();
        for (String cat : new String[]{Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER}) {
            Intent q = new Intent(Intent.ACTION_MAIN).addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(q, 0)) {
                String p = ri.activityInfo.packageName;
                if (!p.equals(getPackageName()) && !m.containsKey(p)) m.put(p, ri);
            }
        }
        return m;
    }

    void showAll() {
        if (overlay != null) return;
        overlay = new FrameLayout(this);
        overlay.setBackgroundColor(0xF0101018);
        overlay.setClickable(true);
        ScrollView sv = new ScrollView(this);
        sv.setClipChildren(false);
        sv.setClipToPadding(false);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setClipChildren(false);
        col.setPadding(dp(60), dp(60), dp(60), dp(40));
        TextView hint = new TextView(this);
        hint.setText("Select to open  \u00B7  Hold select to add to your dock  \u00B7  Back to close");
        hint.setTextColor(0xCCFFFFFF);
        hint.setTextSize(16);
        hint.setPadding(0, 0, 0, dp(24));
        col.addView(hint);
        List<ResolveInfo> list = new ArrayList<>(launchables().values());
        Collections.sort(list, new Comparator<ResolveInfo>() {
            public int compare(ResolveInfo a, ResolveInfo b) {
                return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());
            }
        });
        LinearLayout row = null;
        View first = null;
        int n = 0;
        for (ResolveInfo ri : list) {
            if (n % 7 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setClipChildren(false);
                col.addView(row);
            }
            final String pkg = ri.activityInfo.packageName;
            View it = item(iconView(ri.loadIcon(pm)), ri.loadLabel(pm).toString(),
                v -> { closeOverlay(); launch(pkg); },
                v -> { addFav(pkg); return true; });
            row.addView(it, new LinearLayout.LayoutParams(dp(120), -2));
            if (first == null) first = it;
            n++;
        }
        sv.addView(col);
        overlay.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));
        if (first != null) first.requestFocus();
    }

    void closeOverlay() {
        if (overlay != null) { root.removeView(overlay); overlay = null; buildDock(0); }
    }
}
